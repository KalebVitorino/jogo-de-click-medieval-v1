import {state,setState} from './state/gameState.js';
import {loadSave,saveGame,resetSave} from './state/saveSystem.js';
import {INITIAL,SAVE_VERSION} from './config/constants.js';
import {collect,buyUpgrade,tick} from './systems/economySystem.js';
import {recruit,recalcPower} from './systems/militarySystem.js';
import {nextBattle} from './systems/campaignSystem.js';
import {ensureMission,missionProgress,completeMission} from './systems/missionSystem.js';
import {ensureEvents,startRandomEvent,canResolveEvent,resolveEvent,closeEvent} from './systems/eventSystem.js';
import {renderHud,renderScreen} from './ui/render.js';
import {renderNav} from './ui/navigation.js';
import {STRUCTURE_COSTS} from './config/constants.js';
import {syncHaremPending,acceptPendingWoman,refusePendingWoman,cycleHarem} from './systems/haremSystem.js';

let S=loadSave(); S.saveVersion=SAVE_VERSION; ensureEvents(S); S.barracksMenu=null; S.mapTarget=null; S.modal=null; S.harem=S.harem||{women:[],selectedId:null,pendingId:null,declined:{}}; S.harem.declined=S.harem.declined&&typeof S.harem.declined==='object'&&!Array.isArray(S.harem.declined)?S.harem.declined:{}; setState(S);
const hud=document.querySelector('#hud'),screen=document.querySelector('#screen'),nav=document.querySelector('#nav');

function persist(){saveGame(S)}
function render(){
 syncHaremPending(S);
 renderHud(S,hud); renderScreen(S,screen); renderNav(S,nav,(id)=>{if(S.barracksMenu||S.modal)return;S.screen=id;render()});
 hud.classList.toggle('ui-locked',!!S.barracksMenu||!!S.modal); nav.classList.toggle('ui-locked',!!S.barracksMenu||!!S.modal);
 screen.querySelectorAll('[data-test-gold]').forEach(b=>b.onclick=()=>{S.gold+=500;persist();render()});
 screen.querySelectorAll('[data-test-food]').forEach(b=>b.onclick=()=>{S.food+=500;persist();render()});
 screen.querySelectorAll('[data-open-events]').forEach(b=>b.onclick=()=>{ensureEvents(S);if(!S.events.active)startRandomEvent(S);S.modal='events';persist();render()});
 screen.querySelectorAll('[data-event-choice]').forEach(b=>b.onclick=()=>{if(resolveEvent(S)){persist();render()}});
 screen.querySelectorAll('[data-close-events]').forEach(b=>b.onclick=()=>{closeEvent(S);S.modal=null;persist();render()});
 screen.querySelectorAll('[data-open-missions]').forEach(b=>b.onclick=()=>{ensureMission(S);S.modal='missions';persist();render()});
 screen.querySelectorAll('[data-close-missions]').forEach(b=>b.onclick=()=>{S.modal=null;persist();render()});
 screen.querySelectorAll('[data-open-woman]').forEach(b=>b.onclick=()=>{if(S.harem.pendingId){S.modal='woman-arrival';persist();render()}});
 screen.querySelectorAll('[data-refuse-woman]').forEach(b=>b.onclick=()=>{if(refusePendingWoman(S)){S.modal=null;persist();render()}});
 screen.querySelectorAll('[data-accept-woman]').forEach(b=>b.onclick=()=>{if(acceptPendingWoman(S)){S.modal=null;S.screen='harem';persist();render()}});
 screen.querySelectorAll('[data-harem-prev]').forEach(b=>b.onclick=()=>{cycleHarem(S,-1);persist();render()});
 screen.querySelectorAll('[data-harem-next]').forEach(b=>b.onclick=()=>{cycleHarem(S,1);persist();render()});
 screen.querySelectorAll('[data-test-reset]').forEach(b=>b.onclick=()=>{if(confirm('Resetar todos os valores para o estado inicial?')){resetSave();S=structuredClone({...INITIAL,barracksMenu:null,mapTarget:null,modal:null,saveVersion:SAVE_VERSION});setState(S);render()}});
 screen.querySelectorAll('[data-collect]').forEach(b=>b.onclick=()=>{collect(S,b.dataset.collect);persist();render()});
 screen.querySelectorAll('[data-upgrade]').forEach(b=>b.onclick=()=>{buyUpgrade(S,b.dataset.upgrade);persist();render()});
 screen.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{recruit(S,b.dataset.buy);persist();render()});
 screen.querySelectorAll('[data-open-buy]').forEach(b=>b.onclick=()=>{S.barracksMenu='buy';persist();render()});
 screen.querySelectorAll('[data-open-train]').forEach(b=>b.onclick=()=>{S.barracksMenu='train';persist();render()});
 screen.querySelectorAll('[data-close-barracks]').forEach(b=>b.onclick=()=>{S.barracksMenu=null;persist();render()});
 screen.querySelectorAll('[data-train]').forEach(b=>b.onclick=()=>{alert('O treinamento dos soldados será definido em uma regra própria.');});
 screen.querySelectorAll('[data-map-target]').forEach(b=>b.onclick=()=>{S.mapTarget=b.dataset.mapTarget;S.modal='map-info';persist();render()});
 screen.querySelectorAll('[data-close-map-info]').forEach(b=>b.onclick=()=>{S.modal=null;S.mapTarget=null;persist();render()});
 screen.querySelectorAll('[data-structure]').forEach(b=>b.onclick=()=>{S.modal='structure:'+b.dataset.structure;persist();render()});
 screen.querySelectorAll('[data-close-structure]').forEach(b=>b.onclick=()=>{S.modal=null;persist();render()});
 screen.querySelectorAll('[data-confirm-structure]').forEach(b=>b.onclick=()=>{upgradeStructure(b.dataset.confirmStructure);});
 const attack=screen.querySelector('[data-attack]'); if(attack)attack.onclick=attackBattle;
 const gen=screen.querySelector('[data-generate]'); if(gen)gen.onclick=()=>{ensureMission(S);persist();render()};
 const complete=screen.querySelector('[data-complete]'); if(complete)complete.onclick=()=>{completeMission(S,Number(complete.dataset.complete));persist();render()};
}
function upgradeStructure(id){
 const lv=S.buildings[id], c=STRUCTURE_COSTS[id]?.[lv-1]; if(!c)return;
 const target=lv+1;
 const need=id==='kingdom'?(lv<=3?3:lv<=6?5:8):0;
 let ok=S.gold>=c;
 if(id!=='kingdom') ok=ok&&target<=S.buildings.kingdom;
 if(id==='kingdom') ok=ok&&S.buildings.throne===lv&&S.buildings.barracks===lv&&S.campaign.levelVictories>=need;
 if(!ok)return;
 S.gold-=c; S.buildings[id]++;
 if(id==='kingdom') S.campaign.levelVictories=Math.max(0,S.campaign.levelVictories-need);
 S.modal=null; persist();render();
}
function attackBattle(){
 const b=nextBattle(S); if(!b||S.food<b.food)return;
 S.food-=b.food;
 const mods=[-15,-10,-5,0,5,10,15], mod=mods[Math.floor(Math.random()*mods.length)];
 const effective=Math.floor(S.power*(1+mod/100));
 const won=effective>=b.power;
 S.campaign.pending={battle:S.campaign.currentBattle,modifier:mod,effective,won,reward:won?b.gold+b.bonus:0};
 if(won){S.gold+=b.gold+b.bonus;S.campaign.totalVictories++;S.campaign.levelVictories++;S.campaign.currentBattle++;}
 S.campaign.pending=null;
 ensureMission(S); persist(); alert(won?`Vitória! Condição ${mod>=0?'+':''}${mod}%. Ouro +${b.gold+b.bonus}.`:`Derrota. Condição ${mod>=0?'+':''}${mod}%. Nenhuma recompensa.`); render();
}
setInterval(()=>{tick(S);ensureMission(S);persist();render()},1000);
render();
