export const WOMEN=Array.from({length:20},(_,i)=>{
 const minThrone=i<16?Math.floor(i/2)+2:10;
 return {id:`w${i+1}`,label:`Mulher ${i+1}`,minThrone};
});
