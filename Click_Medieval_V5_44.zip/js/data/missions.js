// Catálogo de missões da V5. As recompensas numéricas ainda não são definidas pela especificação.
export const MISSION_CATALOG=[
 {type:'gold',group:'Trono',label:'Reserva de ouro',description:'Acumule ouro para reforçar a reserva do reino.'},
 {type:'food',group:'Reino',label:'Reserva de comida',description:'Acumule comida para manter o reino abastecido.'},
 {type:'soldiers',group:'Quartel',label:'Preparar soldados',description:'Aumente sua força militar para se aproximar da próxima batalha.'},
 {type:'battle',group:'Mapa',label:'Conquistar território',description:'Vença a próxima batalha da campanha para avançar.'}
];
