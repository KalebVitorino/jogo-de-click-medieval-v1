import {EVENTS} from '../data/events.js';

const EVENT_MULTIPLIERS={
  1:0.30,
  2:0.70,
  3:1.20,
  4:1.80,
  5:2.50,
  6:3.30,
  7:4.20,
  8:5.20,
  9:6.30,
  10:7.50
};

function roundTo(value,step){
 const n=Math.max(0,value||0);
 return Math.max(step,Math.round(n/step)*step);
}

function scaledValue(value,type,multiplier){
 if(!value)return 0;
 return roundTo(value*multiplier,type==='power'?10:50);
}

function scaleEvent(event,kingdomLevel){
 const multiplier=EVENT_MULTIPLIERS[Math.min(10,Math.max(1,kingdomLevel||1))]||EVENT_MULTIPLIERS[1];
 return {
  ...event,
  cost:{
   ...(event.cost||{}),
   ...(event.cost?.gold?{gold:scaledValue(event.cost.gold,'resource',multiplier)}:{}),
   ...(event.cost?.food?{food:scaledValue(event.cost.food,'resource',multiplier)}:{})
  },
  reward:{
   ...(event.reward||{}),
   ...(event.reward?.gold?{gold:scaledValue(event.reward.gold,'resource',multiplier)}:{}),
   ...(event.reward?.food?{food:scaledValue(event.reward.food,'resource',multiplier)}:{}),
   ...(event.reward?.power?{power:scaledValue(event.reward.power,'power',multiplier)}:{})
  }
 };
}

export function ensureEvents(state){
 state.events=state.events||{active:null,nextId:1,lastEventId:null};
 if(!state.events.active)state.events.active=null;
 if(state.events.lastEventId===undefined)state.events.lastEventId=null;
 return state.events;
}

export function startRandomEvent(state){
 ensureEvents(state);
 if(state.events.active)return false;
 const pool=EVENTS.filter(event=>event.id!==state.events.lastEventId);
 const choices=pool.length?pool:EVENTS;
 const baseEvent=choices[Math.floor(Math.random()*choices.length)];
 const event=scaleEvent(baseEvent,state.buildings?.kingdom||1);
 state.events.active={...event,cost:{...(event.cost||{})},reward:{...(event.reward||{})},resolved:false};
 state.events.lastEventId=event.id;
 return true;
}

export function canResolveEvent(state,event){
 return (!event.cost.gold||state.gold>=event.cost.gold)&&(!event.cost.food||state.food>=event.cost.food);
}

export function resolveEvent(state){
 ensureEvents(state);
 const event=state.events.active;
 if(!event||event.resolved||!canResolveEvent(state,event))return false;
 if(event.cost.gold)state.gold-=event.cost.gold;
 if(event.cost.food)state.food-=event.cost.food;
 if(event.reward.gold)state.gold+=event.reward.gold;
 if(event.reward.food)state.food+=event.reward.food;
 if(event.reward.power){state.bonusPower=(state.bonusPower||0)+event.reward.power;state.power=(state.power||0)+event.reward.power;}
 event.resolved=true;
 return true;
}

export function closeEvent(state){
 ensureEvents(state);
 state.events.active=null;
}

export {EVENT_MULTIPLIERS};
