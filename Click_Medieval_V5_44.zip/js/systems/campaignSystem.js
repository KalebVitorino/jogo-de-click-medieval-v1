import {BATTLES} from '../config/constants.js';
export function nextBattle(state){return BATTLES[state.campaign.currentBattle-1]||null}
export function territoryProgress(state){return {cervo:Math.min(3,Math.max(0,state.campaign.currentBattle-1)),aguia:Math.min(3,Math.max(0,state.campaign.currentBattle-4)),negra:Math.min(4,Math.max(0,state.campaign.currentBattle-7))}}
