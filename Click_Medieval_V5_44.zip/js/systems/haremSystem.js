import {WOMEN} from '../data/women.js';
export function syncHaremPending(state){
 state.harem.declined=state.harem.declined&&typeof state.harem.declined==='object'&&!Array.isArray(state.harem.declined)?state.harem.declined:{};
 if(state.harem.pendingId){
  const pending=WOMEN.find(w=>w.id===state.harem.pendingId);
  if(pending&&state.buildings.throne>=pending.minThrone&&!state.harem.women.includes(pending.id)&&state.harem.women.length<state.buildings.throne*2)return;
  state.harem.pendingId=null;
 }
 if(state.harem.women.length>=state.buildings.throne*2)return;
 const next=WOMEN.find(w=>!state.harem.women.includes(w.id)&&state.buildings.throne>=w.minThrone&&(!state.harem.declined[w.id]||state.buildings.throne>state.harem.declined[w.id]));
 if(next)state.harem.pendingId=next.id;
}
export function acceptPendingWoman(state){
 const w=WOMEN.find(x=>x.id===state.harem.pendingId);
 if(!w||state.buildings.throne<w.minThrone||state.harem.women.length>=state.buildings.throne*2)return false;
 state.harem.women.push(w.id); state.harem.selectedId=w.id; state.harem.pendingId=null;
 delete state.harem.declined[w.id];
 return true;
}
export function refusePendingWoman(state){
 const w=WOMEN.find(x=>x.id===state.harem.pendingId);
 if(!w)return false;
 state.harem.declined[w.id]=state.buildings.throne;
 state.harem.pendingId=null;
 return true;
}
export function cycleHarem(state,delta){
 const women=state.harem.women.map(id=>WOMEN.find(w=>w.id===id)).filter(Boolean); if(!women.length)return;
 let i=women.findIndex(w=>w.id===state.harem.selectedId); if(i<0)i=0;
 i=(i+delta+women.length)%women.length; state.harem.selectedId=women[i].id;
}
export function selectedWomen(state){return state.harem.women.map(id=>WOMEN.find(w=>w.id===id)).filter(Boolean)}
