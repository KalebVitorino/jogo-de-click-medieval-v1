import {TROOPS} from '../config/constants.js';
export function recruit(state,id){const t=TROOPS[id];if(state.food<t.cost)return false;state.food-=t.cost;state.troops[id]++;recalcPower(state);return true}
export function recalcPower(state){state.power=Object.entries(state.troops).reduce((sum,[id,n])=>sum+(TROOPS[id].power*n),0)+(state.bonusPower||0)}
