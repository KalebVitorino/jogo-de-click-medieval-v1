import {MISSION_CATALOG} from '../data/missions.js';
import {rate,clickGain} from './economySystem.js';
import {nextBattle} from './campaignSystem.js';

function totalSoldiers(state){return Object.values(state.troops||{}).reduce((a,b)=>a+Number(b||0),0)}

function difficultResourceTarget(state,resource,multiplier){
 const production=rate(state,resource)+clickGain(state,resource);
 return Math.max(30,Math.ceil(production*multiplier));
}

function recruitmentTarget(state){
 const battle=nextBattle(state);
 if(!battle)return Math.max(10,state.power);
 const gap=Math.max(0,battle.power-Number(state.power||0));
 if(gap<=0)return Math.max(10,Math.ceil(Number(state.power||0)*0.25));
 return Math.max(10,Math.ceil(gap*2/3));
}

function buildDefinitions(state){
 const resourceMultiplier=Math.random()<0.5?30:50;
 return [
  {type:'gold',group:'Trono',label:resourceMultiplier===30?'Reserva de ouro':'Grande reserva de ouro',description:resourceMultiplier===30?'Acumule ouro para reforçar a reserva do reino.':'Acumule uma grande reserva de ouro para preparar o próximo avanço.',target:difficultResourceTarget(state,'gold',resourceMultiplier),baseline:state.gold},
  {type:'food',group:'Reino',label:resourceMultiplier===30?'Reserva de comida':'Grande reserva de comida',description:resourceMultiplier===30?'Acumule comida para manter o reino abastecido.':'Acumule uma grande reserva de comida para preparar o próximo avanço.',target:difficultResourceTarget(state,'food',resourceMultiplier),baseline:state.food},
  {type:'soldiers',group:'Quartel',label:'Preparar soldados',description:'Aumente sua força militar para se aproximar da próxima batalha.',target:recruitmentTarget(state),baseline:Number(state.power||0)},
  {type:'battle',group:'Mapa',label:'Conquistar território',description:'Vença a próxima batalha da campanha para avançar.',target:1,baseline:state.campaign.totalVictories}
 ];
}

export function ensureMission(state){
 if(state.missions.active.length) return;
 const defs=buildDefinitions(state);
 const c=MISSION_CATALOG[state.missions.nextId%MISSION_CATALOG.length];
 const d=defs.find(x=>x.type===c.type);
 state.missions.active=[{id:state.missions.nextId++,...d,createdAt:Date.now(),rulesVersion:2}];
}

export function missionProgress(state,m){
 if(m.type==='gold') return Math.max(0,state.gold-m.baseline);
 if(m.type==='food') return Math.max(0,state.food-m.baseline);
 if(m.type==='soldiers') return Math.max(0,Number(state.power||0)-m.baseline);
 if(m.type==='battle') return Math.max(0,state.campaign.totalVictories-m.baseline);
 return 0;
}

export function completeMission(state,id){
 const m=state.missions.active.find(x=>x.id===id); if(!m)return false;
 if(missionProgress(state,m)<m.target)return false;
 state.missions.active=state.missions.active.filter(x=>x.id!==id);
 state.missions.completed++;
 return true;
}
