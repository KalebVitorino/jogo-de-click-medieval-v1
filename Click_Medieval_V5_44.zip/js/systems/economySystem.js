const GROWTH=1.28;
export const UPGRADES={
 goldPerSecond:{label:'Ouro por segundo',resource:'gold',base:60,gain:'+1 ouro/s'},
 foodPerSecond:{label:'Comida por segundo',resource:'gold',base:60,gain:'+1 comida/s'},
 goldPerClick:{label:'Ouro por clique',resource:'gold',base:40,gain:'+1 ouro/clique'},
 foodPerClick:{label:'Comida por clique',resource:'gold',base:40,gain:'+1 comida/clique'}};
export function upgradeCost(state,id){const u=UPGRADES[id],n=state.upgrades[id]||0;return Math.round((u.base*Math.pow(GROWTH,n))/5)*5}
export function upgradeLimit(state){return Math.max(1,Number(state.buildings?.kingdom)||1)*10}
export function clickGain(state,r){return 1+(state.upgrades[r==='gold'?'goldPerClick':'foodPerClick']||0)}
export function rate(state,r){return state.upgrades[r==='gold'?'goldPerSecond':'foodPerSecond']||0}
export function collect(state,r){state[r]+=clickGain(state,r)}
export function buyUpgrade(state,id){const u=UPGRADES[id],n=state.upgrades[id]||0,c=upgradeCost(state,id);if(n>=upgradeLimit(state)||state[u.resource]<c)return false;state[u.resource]-=c;state.upgrades[id]++;return true}
export function tick(state){state.gold+=rate(state,'gold');state.food+=rate(state,'food')}
