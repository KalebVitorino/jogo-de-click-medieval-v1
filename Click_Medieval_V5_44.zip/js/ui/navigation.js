export const NAV=[['throne','Trono','♛'],['kingdom','Reino','♜'],['harem','Harém','♥'],['barracks','Quartel','⚔'],['map','Mapa','⚔']];
export function renderNav(state,root,onNav){
 root.innerHTML=NAV.map(([id,label,icon])=>`<button class="nav-item ${state.screen===id?'active':''}" data-nav="${id}"><span class="nav-icon">${icon}</span><span class="nav-label">${label}</span></button>`).join('');
 root.querySelectorAll('[data-nav]').forEach(b=>b.onclick=(event)=>{event.preventDefault();onNav(b.dataset.nav)});
}
