export const SAVE_VERSION=2;
export const INITIAL={gold:50,food:50,power:0,bonusPower:0,screen:'throne',
buildings:{kingdom:1,throne:1,barracks:1},
campaign:{totalVictories:0,levelVictories:0,currentBattle:1,pending:null},
troops:{infantry:0,archer:0,cavalry:0},
upgrades:{goldPerSecond:0,foodPerSecond:0,goldPerClick:0,foodPerClick:0},
missions:{active:[],completed:0,nextId:1},
events:{active:null,nextId:1},
harem:{women:[],selectedId:null,pendingId:null,declined:{}}};
export const TROOPS={
 infantry:{name:'Infantaria',cost:20,power:10,icon:'⚔'},
 archer:{name:'Arqueiro',cost:35,power:18,icon:'➶'},
 cavalry:{name:'Cavaleiro',cost:60,power:35,icon:'♞'}};
export const BATTLES=[
 {territory:'Reino do Cervo',stage:1,power:120,food:20,gold:60,bonus:0},
 {territory:'Reino do Cervo',stage:2,power:500,food:25,gold:75,bonus:0},
 {territory:'Reino do Cervo',stage:3,power:650,food:35,gold:100,bonus:500},
 {territory:'Reino da Águia',stage:1,power:845,food:30,gold:90,bonus:0},
 {territory:'Reino da Águia',stage:2,power:1100,food:40,gold:115,bonus:0},
 {territory:'Reino da Águia',stage:3,power:1430,food:50,gold:145,bonus:725},
 {territory:'Fortaleza Negra',stage:1,power:1860,food:45,gold:140,bonus:0},
 {territory:'Fortaleza Negra',stage:2,power:2420,food:60,gold:180,bonus:0},
 {territory:'Fortaleza Negra',stage:3,power:3145,food:75,gold:230,bonus:0},
 {territory:'Fortaleza Negra',stage:4,power:4090,food:95,gold:295,bonus:1475}];
export const STRUCTURE_COSTS={
 kingdom:[10000,30000,90000,270000,800000,2400000,7000000,21000000,60000000],
 throne:[8000,24000,70000,210000,620000,1800000,5400000,16000000,45000000],
 barracks:[6000,18000,55000,165000,500000,1500000,4500000,13000000,38000000]};
