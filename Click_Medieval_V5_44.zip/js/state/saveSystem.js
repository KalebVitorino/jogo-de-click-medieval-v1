import {INITIAL,SAVE_VERSION} from '../config/constants.js';

const KEY='click-medieval-v5-save';

export function loadSave(){
 try{
  const raw=JSON.parse(localStorage.getItem(KEY)||'null');
  if(!raw)return freshState();
  const saved=raw.state&&typeof raw.state==='object'?raw.state:raw;
  return normalize(deepMerge(freshState(),saved));
 }catch{return freshState()}
}

function freshState(){
 return structuredClone({...INITIAL,barracksMenu:null,mapTarget:null,modal:null,saveVersion:SAVE_VERSION});
}

function deepMerge(base,extra){
 for(const k of Object.keys(extra||{})){
  const value=extra[k];
  if(value&&typeof value==='object'&&!Array.isArray(value)&&base[k]&&typeof base[k]==='object'&&!Array.isArray(base[k])) base[k]=deepMerge(base[k],value);
  else if(value!==undefined) base[k]=value;
 }
 return base;
}

function normalize(state){
 state.saveVersion=SAVE_VERSION;
 state.harem=state.harem||{women:[],selectedId:null,pendingId:null,declined:{}};
 state.harem.women=Array.isArray(state.harem.women)?state.harem.women:[];
 state.harem.selectedId=state.harem.selectedId??null;
 state.harem.pendingId=state.harem.pendingId??null;
 state.harem.declined=state.harem.declined&&typeof state.harem.declined==='object'&&!Array.isArray(state.harem.declined)?state.harem.declined:{};
 state.missions=state.missions||{active:[],completed:0,nextId:1};
 state.events=state.events||{active:null,nextId:1,lastEventId:null};
 state.missions.active=Array.isArray(state.missions.active)?state.missions.active:[];
 state.events.active=state.events.active&&typeof state.events.active==='object'?state.events.active:null;
 state.events.nextId=Number.isFinite(state.events.nextId)?state.events.nextId:1;
 state.events.lastEventId=typeof state.events.lastEventId==='string'?state.events.lastEventId:null;
 state.campaign=state.campaign||{totalVictories:0,levelVictories:0,currentBattle:1,pending:null};
 state.bonusPower=Number.isFinite(state.bonusPower)?state.bonusPower:0;
 state.campaign.pending=null;
 state.barracksMenu=null;
 state.mapTarget=null;
 state.modal=null;
 delete state.population;
 delete state.peakPopulation;
 return state;
}

export function saveGame(state){
 const snapshot=normalize(structuredClone(state));
 localStorage.setItem(KEY,JSON.stringify({version:SAVE_VERSION,state:snapshot}));
}

export function resetSave(){localStorage.removeItem(KEY)}
