import {INITIAL,SAVE_VERSION} from '../config/constants.js';
export let state=structuredClone({...INITIAL,barracksMenu:null,mapTarget:null,modal:null,saveVersion:SAVE_VERSION});
export function setState(next){state=next}
