# Click Medieval V5-44

Implementação inicial do sistema de Eventos.

## Eventos
- 18 eventos aprovados em 6 grupos: Economia, Militar, Reino, Recursos, Ameaças / Segurança e Política / Nobres.
- Grupo Especiais ficou fora desta versão.
- Um evento por vez.
- O evento é sorteado aleatoriamente quando o botão Eventos é aberto.
- O jogador escolhe executar ou recusar.
- Custos e recompensas são mostrados objetivamente.
- Custos de melhorias do Reino, Trono e Quartel não são alterados por eventos.
- Recompensas de Poder Militar usam bônus persistente separado para não serem apagadas pelo recálculo das tropas.
- Após resolver/recusar, o evento atual é encerrado e outro só pode surgir em uma nova abertura do botão Eventos.


## Regra de repetição de eventos
- O mesmo evento não pode ser sorteado imediatamente após si mesmo.
- A comparação usa o ID do evento, independentemente de valores de custo/recompensa.
- Após outro evento ocorrer, o evento anterior volta a poder ser sorteado normalmente.
- O último evento é persistido no save.

## Balanceamento progressivo dos eventos
- Os 18 eventos mantêm seus valores-base aprovados.
- Ao gerar um novo evento, o custo e a recompensa são calculados pelo multiplicador do nível atual do Reino.
- Multiplicadores: R1 0,30×; R2 0,60×; R3 1,00×; R4 1,50×; R5 2,10×; R6 2,80×; R7 3,70×; R8 4,80×; R9 6,10×; R10 7,70×.
- Ouro e comida são arredondados para múltiplos de 50. Poder Militar é arredondado para múltiplos de 10.
- O valor do evento fica congelado no momento em que ele é sorteado.
